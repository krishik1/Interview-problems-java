package com.example.generateinvoices.models;

public enum RoomType {
    DELUXE,
    SUPER_DELUXE,
    SUITE
}
