package com.example.generateinvoices.models;

public enum CustomerSessionStatus {
    ACTIVE, ENDED;
}
