package com.example.generateinvoices.dtos;

public enum ResponseStatus {
    SUCCESS,
    FAILURE
}
