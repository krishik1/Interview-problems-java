package com.example.generateinvoices.models;

public enum UserType {
    CUSTOMER, ADMIN
}
