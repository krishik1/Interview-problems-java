package com.example.generateinvoices.exceptions;

public class CustomerSessionNotFoundException extends Exception {
    public CustomerSessionNotFoundException(String message) {
        super(message);
    }
}
