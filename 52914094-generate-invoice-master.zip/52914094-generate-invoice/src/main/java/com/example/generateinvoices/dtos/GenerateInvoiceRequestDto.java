package com.example.generateinvoices.dtos;

public class GenerateInvoiceRequestDto {
    private long userId;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }
}
